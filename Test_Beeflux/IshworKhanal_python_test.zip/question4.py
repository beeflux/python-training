'''

  Q4.
Whats the difference between tuple and list.

Consider a list
l = [1,2,3,4,5,6,7,8,9]

how can you get last 4 items in l

 ANSWER: to first question

 the main difference between he tuple and list is :
  list is mutable i.e. they can be modified
  tuple are immutable i.e. they cant be modified once declared


'''

l = [1,2,3,4,5,6,7,8,9]

print( l [-4:])  #answer to second question

  
