'''

   Q3.
Consider a function

def student(name, roll, age, address):
    print(name, roll, age, address)



a. What would be output of followings
    student(“pratima”, name=”pratima”, 20, 20, 20)
    student(“pratima”, 20, age=25, “kathmandu”)
   student(“pratima”)
   
'''




#print(student("pratima", name="pratima", 20, 20, 20)) gives error as here positional arguement follows keyword argurment
    
#print(student("pratima", 20, age=25, "kathmandu")) gives error as here positional arguement follows keyword argurment

#print(student("pratima")) gives error as othe parameters are not passed to he function


