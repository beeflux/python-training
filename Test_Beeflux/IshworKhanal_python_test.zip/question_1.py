def my_sum(*args):
    print(sum(args))

my_sum(1,2)
my_sum(1,2,3)
my_sum(1,3,5,7,8)
    
    
