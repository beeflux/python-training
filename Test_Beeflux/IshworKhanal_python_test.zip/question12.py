'''

  Q12.

Write a program to create a flie name bee.txt write “hello bee to it”

write another program to read the contents of bee.txt in uppercase.


'''

f = open(r"C:\Users\Dell\Documents\GitHub\python-training\Python_test\test.txt",'a+')
f.write("hello bee ")
f.close()
