d = {1:1, 2:2, 3:3}

#print(d[4]) ,there is no key "4" in the dictionary

#setting "9" value in key 2
d[2]= 9
print(d[2])





